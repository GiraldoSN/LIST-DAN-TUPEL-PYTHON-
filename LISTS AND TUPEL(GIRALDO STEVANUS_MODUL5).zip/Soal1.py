while True:
    list1=[]
    for i in range(5):
        item = input("Masukkan 15 nama makanan: ")
        list1.append(item)

    list2=[]
    for i in range(5):
        item2 = input("Masukkan 5 nama minuman: ")
        list2.append(item2)
    
    list3=[]
    for i in range(5):
        item3 = input("Masukkan 5 nama teman: ")
        list3.append(item3)

    list4=[]
    for i in range(5):
        item4 = input("Masukkan 5 bulan lahir teman: ")
        list4.append(item4)
    
    list5=[]
    for i in range(5):
        item5 = input("Masukkan 5 tanggal lahir teman: ")
        list5.append(item5)

    # rubah list3 index 3 dan 5
    index4 = [str(input("masukkan update output 2 yang diinginkan pada list3 index 3: "))]
    index5 = [str(input("masukkan update output 2 yang diinginkan pada list3 index 5: "))]
    
    # output pertama
    print (list1[0:5] + list2)
    # output kedua
    list3[3] = [4]
    list3[4] = [5]
    print(list3)
    print ("nilai baru dari list3 index 3 adalah",index4," dan nilai baru dari list3 index 4 adalah",index5)
    # output ketiga
    del list5[1]
    del list5[4]
    print("setelah index 1 dan 4 dihapus:",list5)
    # output keempat
    a = list4 + list5
    print(a)
    print ("nilai max dari keduanya adalah",max(a),"dan nilai min dari keduanya adalah",min(a))

    
    n = str(input("ingin mengulang y atau n?: "))
    if n == "y":
        continue
    elif n == "n":
        print("program berakhir")
        break
    else:
        print("tidak ada dalam pilihan program berakhir")
        break
