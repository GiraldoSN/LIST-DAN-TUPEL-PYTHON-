
# Program 2
# Data_Tuple
print("Tuple 1 : Nama Kota")
Tuple1 = (input(tuple()),input(tuple()),input(tuple()),input(tuple()),input(tuple()))
Tuple2 = (12,20,23,31,19,30,45,98)
Tuple3 = ("pEmograman", "pemograman", "Pemograman", "PemOgRamAn", "PEMOGRAMAN")
print("=========================================")

print("output 1 :")
print(Tuple3[1],Tuple3[3],Tuple3[4],Tuple1[3],Tuple1[1])
print("=========================================")
print("output 2 : ")
for i in range(1,4) :
    a = Tuple2[1]
    print(a)
    b = Tuple2[4]
    print(b)